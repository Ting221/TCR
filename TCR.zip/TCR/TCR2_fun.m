function [b_tplus1]=TCR2_fun(data,tday,b_t_hat,rho,lambda,win_size)
%% algorithm parameter and iteration setting
max_iter = 1e4;                          %the maximum number of iterations
ABSTOL = 1e-4;                           %iteration tolerance

m=size(data,2);
I=ones(m,1);
z=zeros(m,1);                            %project onto R_m^+

alpha=0.999/(rho*m);                     %parameter controlling the convergence of the algorithm
cathy=10;                                %initialize the Lagrange Multiplier
b=ones(m,1)/m;                           %initialize portfolio in the subproblem in each iteration
b_old=ones(m,1)/m;                       %initialize old portfolio in the subproblem in each iteration

%% Price prediction
x_wan=1;
temp=1;
for k=1:win_size-1
    if tday-k+1<=0
        k=k-1;
        break
    end
    x_tcutkplus1=data(tday-k+1,:)';
    x_wan=x_wan+temp./x_tcutkplus1;
    temp=temp./x_tcutkplus1;
end
f2=x_wan/(k+1);

%% main
for iter=1:max_iter
    b_temp=b-b_t_hat+alpha*f2-alpha*I*cathy-alpha*rho*I*(I'*b-1);
    b=b_t_hat+wthresh(b_temp,'s',alpha*lambda);
    b(b<0)=z(b<0);                                        %project onto R_m^+
    cathy=cathy+rho*(I'*b-1);                             %update the Lagrange Multiplier
    prim_res=norm(b-b_old,2)/norm(b,2);                   %compute the iteration tolerance      
    b_old=b;

    if (prim_res)<ABSTOL        
         break;
    end  
    
end

b_tplus1=b;  

end
