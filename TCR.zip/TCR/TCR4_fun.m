function [b_tplus1]=TCR4_fun(data,tday,b_t_hat,rho,lambda,win_size)
%% algorithm parameter and iteration setting
max_iter = 1e4;                          %the maximum number of iterations
ABSTOL = 1e-4;                           %iteration tolerance

m=size(data,2);

cathy=zeros(m,1)/m;                      %initialize the Lagrange Multiplier
b=ones(m,1)/m;                           %initialize portfolio in the subproblem in each iteration
d=b;                                     %initialize dual variable in the subproblem in each iteration
b_old=ones(m,1)/m;                       %initialize old portfolio in the subproblem in each iteration

%% Price prediction
x_wan=1;
temp=1;
for k=1:win_size-1
    if tday-k+1<=0
        k=k-1;
        break
    end
    x_tcutkplus1=data(tday-k+1,:)';
    x_wan=x_wan+temp./x_tcutkplus1;
    temp=temp./x_tcutkplus1;
end
f2=x_wan/(k+1);

%% main
for iter=1:max_iter
    %update the portfolio
    b=(1/rho)*(f2-cathy+rho*d);
    b=simplex_projection_selfnorm2(b,1);
    
    %update the dual variable
    d_temp=cathy/rho+b-b_t_hat;
    d=b_t_hat+wthresh(d_temp,'s',lambda/rho);
    
    %update the Lagrange Multiplier
    cathy=cathy+rho*(b-d);
    
    %compute the iteration tolerance
    prim_res=norm(b-b_old,2)/norm(b,2);      
    
    b_old=b;

    if (prim_res)<ABSTOL        
         break;
    end  
    
end

b_tplus1=b;  

end
